#include <stdio.h>

void main(){

   printf("Days of the week\n");
   printf("Sunday\n");
   printf("Monday\n");
   printf("Tuesday\n");
   printf("Wednesday\n");
   printf("Thursday\n");
   printf("Friday\n");
   printf("Saturday\n");

}